
public interface FileManager {
	void storeDSA(String fileName);
	void store(String fileName);
}
