
public interface EsameManager {
	boolean addEsame(Esame e,Studente s);
}
