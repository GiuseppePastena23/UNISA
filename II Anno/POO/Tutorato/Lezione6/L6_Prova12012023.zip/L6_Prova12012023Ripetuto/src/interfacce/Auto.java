package interfacce;

import eccezioni.MotoreException;

//3 Punti per interfaccia ed Eccezioni
public interface Auto
{
	void Accendi (Auto a) throws MotoreException;
}
