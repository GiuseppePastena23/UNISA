package test;

import gui.MainWindow;

//4 Punti
public class TestGUI {

	public static void main(String[] args) 
	{
		MainWindow w = new MainWindow("Prova del 12/01/2023");
		w.setVisible(true);
	}

}
