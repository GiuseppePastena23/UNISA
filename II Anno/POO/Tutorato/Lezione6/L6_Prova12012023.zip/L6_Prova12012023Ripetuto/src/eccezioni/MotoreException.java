package eccezioni;

public class MotoreException extends Exception 
{

	public MotoreException() 
	{
		super("Motore Acceso!");
		// TODO Auto-generated constructor stub
	}

	public MotoreException(String message) 
	{
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
