package test;

import gui.MainWindow;

public class Tester2 {

	public static void main(String[] args) 
	{
		MainWindow w = new MainWindow("Esercizio 3");
		w.setVisible(true);
	}

}
