package interfacce;
import core.Locale;

public interface LocaleOptions 
{
	void prenotazione(int numPersone,Locale l);
	void printInfo();
	void registraLocale(Locale l);
}
