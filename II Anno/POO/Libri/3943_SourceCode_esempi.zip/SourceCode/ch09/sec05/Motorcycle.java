public class Motorcycle extends Vehicle
{
   public Motorcycle()
   {
      setNumberOfTires(2);
   }
}

