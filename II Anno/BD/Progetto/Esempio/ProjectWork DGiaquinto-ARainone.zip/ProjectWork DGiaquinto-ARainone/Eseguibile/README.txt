Daniele Giaquinto, Andrea Rainone - Progetto Basi di Dati - Anno Corso 2020/21

Istruzioni per l'esecuzione:
- Avviare le query di creazione
- Avviare le query di inserimento
= Avviare DeliveryUltra.jar
- Specificare i dati di connessione al DB e clickare su ACCEDI //Attenzione, l'accesso al DB ha un piccolo bug che permette l'accesso al programma anche se il DB non e' attivo o non esiste

