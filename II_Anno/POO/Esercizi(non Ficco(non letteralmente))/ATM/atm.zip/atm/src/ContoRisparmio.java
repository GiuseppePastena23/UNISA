

public class ContoRisparmio extends Conto {

	public ContoRisparmio(double d) {
		super.saldo = d;
	}

}
