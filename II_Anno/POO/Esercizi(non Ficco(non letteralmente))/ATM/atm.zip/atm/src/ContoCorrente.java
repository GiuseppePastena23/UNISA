

public class ContoCorrente extends Conto {
	
	public ContoCorrente(double d) {
		super.saldo = d;
	}

}
