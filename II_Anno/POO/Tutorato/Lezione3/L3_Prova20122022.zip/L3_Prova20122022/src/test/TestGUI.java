package test;

import gui.MainGUI;

//4 Punti
public class TestGUI 
{
	public static void main(String args[])
	{
		MainGUI gui = new MainGUI("Prova 22/12/2022 - PacchiManager");
		gui.setVisible(true);
	}
}
