package interfacce;

import core.Pacco;

//2 Punti
public interface Lista 
{
	boolean Aggiungi(Pacco d);
	boolean Rimuovi(Pacco d);
}
