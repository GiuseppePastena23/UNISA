package tester;

import gui.MainGUI;

public class TesterGUI {

	public static void main(String[] args) 
	{
		MainGUI app = new MainGUI("Esercizio 2 - Lezione 2");
		app.setVisible(true);
	}

}
