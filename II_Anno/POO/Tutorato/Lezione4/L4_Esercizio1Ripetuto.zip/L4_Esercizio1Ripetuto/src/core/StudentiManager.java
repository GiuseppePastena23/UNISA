package core;

import java.util.List;
import java.util.Vector;

import interfacce.StudentiOperations;

public class StudentiManager implements StudentiOperations
{
	private List<Studente> studenti;

	public StudentiManager() 
	{
		this.studenti = new Vector<Studente>();
	}

	public boolean add(Studente s) 
	{
		if(this.studenti.contains(s)) return false;
		else this.studenti.add(s);
		
		return true;
	}

	public boolean remove(Studente s) 
	{
		if(! this.studenti.contains(s))
		{
			this.studenti.add(s);
			return true;
		}
		else return false;
	}

	public boolean addCorso(Studente s, Corso c) 
	{
		if(s.getCorsi().contains(c)) return false;
		else
		{
			for(int i = 0; i < this.studenti.size(); i++) 
				if(this.studenti.get(i).equals(s))
				{
					this.studenti.get(i).getCorsi().add(c);
					break;
				}
			
			return true;
		}
	}

	public List<Studente> getStudenti() {
		return studenti;
	}

	public void setStudenti(List<Studente> studenti) {
		this.studenti = studenti;
	}

}
