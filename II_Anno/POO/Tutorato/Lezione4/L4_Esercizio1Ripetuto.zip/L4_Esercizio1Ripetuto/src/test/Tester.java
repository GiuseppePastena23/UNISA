package test;

import gui.StudenteGUI;

public class Tester {

	public static void main(String[] args)
	{
		StudenteGUI gui = new StudenteGUI("Lezione 4 - Esercizio 1");
		gui.setVisible(true);
	}

}
