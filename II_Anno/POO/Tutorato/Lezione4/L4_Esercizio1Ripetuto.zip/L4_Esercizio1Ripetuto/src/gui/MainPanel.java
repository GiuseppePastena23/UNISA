package gui;

import javax.swing.JPanel;
import core.StudentiManager;

public class MainPanel extends JPanel 
{
	private StudentiManager m;
	
	public MainPanel() 
	{
		this.m = new StudentiManager();
		buildPanel();
	}
	
	private void buildPanel()
	{
		
	}
}
