package core;

public interface MaliciousActions 
{
	void doAction(String messageActionDone);
}
