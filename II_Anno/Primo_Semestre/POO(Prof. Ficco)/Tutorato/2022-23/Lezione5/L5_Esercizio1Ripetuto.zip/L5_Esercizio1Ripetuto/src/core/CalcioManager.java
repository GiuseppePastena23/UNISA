package core;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class CalcioManager 
{
	private List<Squadra> campionato;
	private String nomeCampionato;
	
	public CalcioManager(String nomeCampionato) 
	{
		this.campionato = new ArrayList<Squadra>();
		this.nomeCampionato = nomeCampionato;
	}

	public List<Squadra> getCampionato() {
		return campionato;
	}

	public void setCampionato(List<Squadra> campionato) {
		this.campionato = campionato;
	}

	public String getNomeCampionato() {
		return nomeCampionato;
	}

	public void setNomeCampionato(String nomeCampionato) {
		this.nomeCampionato = nomeCampionato;
	}
	
	
	public void printAllPlayerByCondition(Predicate<Calciatore> pred,Consumer<Calciatore> cons)
	{
		this.campionato.stream().forEach(s -> s.printPlayerByNum(pred, cons));
	}
}
