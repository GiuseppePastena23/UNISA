package core;
import java.util.*;

import interfacce.FileManager;

import java.io.*;

public class DipendentiManager implements FileManager
{
	
	private List<Dipendente> dipendenti;
	
	public DipendentiManager() {}

	public List<Dipendente> getDipendenti() {
		return dipendenti;
	}

	public void setDipendenti(List<Dipendente> dipendenti) {
		this.dipendenti = dipendenti;
	}
	
	public List<Dipendente> getStagisti()
	{
		ArrayList<Dipendente> list = new ArrayList<Dipendente>();
		
		for(int i=0; i<this.dipendenti.size(); i++)
		{
			if(this.dipendenti.get(i) instanceof Stagista) list.add(this.dipendenti.get(i));
		}
		
		return (List<Dipendente>) list;
	}
	
	public void printDipendentiBySalario(int soglia)
	{
		for(int i=0; i<this.dipendenti.size() ;i++)
		{
			Dipendente app = this.dipendenti.get(i);
			if(app.calcolaStipendio() > soglia) System.out.println(app);
		}
	}

	@Override
	public void readLavoratori(String fileName) 
	{
		try
		{
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName));
			
			this.dipendenti = (ArrayList<Dipendente>) in.readObject();
			
			in.close();
		}
		catch (EOFException e)
		{
			System.out.println("Fine stream");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	public void saveLavoratoriSerializable(String fileName) 
	{
		try
		{
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fileName));
			
			out.writeObject(this.dipendenti);
			
			out.close();
		}
		catch (EOFException e)
		{
			System.out.println("Fine stream");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void saveLavoratori(String fileName) 
	{
		PrintWriter out = null;
		
		try
		{
			out = new PrintWriter(new BufferedWriter(new FileWriter(fileName)));
			
			//Da Implementare
			
			out.close();
		}
		catch (EOFException e)
		{
			System.out.println("Fine stream");
			out.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			out.close();
		}
		
	}
}
