package interfacce;

public interface FileManager 
{
	void readLavoratori(String fileName);
	void saveLavoratori(String fileName);
}
