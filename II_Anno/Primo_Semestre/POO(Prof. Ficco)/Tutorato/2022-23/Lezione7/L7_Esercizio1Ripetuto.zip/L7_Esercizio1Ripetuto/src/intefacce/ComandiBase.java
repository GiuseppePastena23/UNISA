package intefacce;

import core.Player;

public interface ComandiBase 
{
	boolean attacco(Player other);
	void potenziamento();
}
