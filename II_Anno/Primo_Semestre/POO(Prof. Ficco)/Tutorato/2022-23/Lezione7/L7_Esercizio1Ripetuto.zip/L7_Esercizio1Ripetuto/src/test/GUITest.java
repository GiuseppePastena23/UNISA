package test;

import gui.GUI;

public class GUITest {

	public static void main(String[] args) 
	{
		GUI gui = new GUI("Players Fantastici");
		gui.setVisible(true);

	}

}
